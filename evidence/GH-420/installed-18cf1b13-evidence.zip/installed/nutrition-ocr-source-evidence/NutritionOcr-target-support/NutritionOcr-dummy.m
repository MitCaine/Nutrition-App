#import <Foundation/Foundation.h>
@interface PodsDummy_NutritionOcr : NSObject
@end
@implementation PodsDummy_NutritionOcr
@end
